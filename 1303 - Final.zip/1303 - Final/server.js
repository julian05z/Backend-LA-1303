const express = require('express');
const app = express();



let data = require('./daten')



app.get('/InitialData', (req,res) => {

 res.setHeader("Access-Control-Allow-Origin", "http://127.0.0.1:5502")  

  try {
    res.json(data)
  }
  catch(e) {
    console.log(e)
  }
  
  console.log(data)
});

app.listen(4000, ()=>{  
    console.log("listening to port 4000")
});