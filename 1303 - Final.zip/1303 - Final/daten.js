module.exports = {
    InitialData: [

    { 
        id: 1, 
        name: "Peter Burkard",
        alter: "25 Jahre alt.",
        wohnort: "Aarau",
        beruf: "Architekt"
    },

    {
        id: 2, 
        name: "Janin Möckel",
        alter: "52 Jahre alt.",
        wohnort: "Wettingen.",
        beruf: "Busfahrer"
    }, 

    {
        id: 3,
        name: "Nicola Süss",
        alter: "35 Jahre alt",
        wohnort: "Basel",
        beruf: "Lehrer"
    },

    {
        id:4, 
        name: "Leano Hunzicker",
        alter: "36 Jare alt.",
        wohnort: "Olten",
        beruf: "Informatiker"
    },

    {
        id: 5,
        name: "Mila Jud",
        alter: "53 Jahre alt.",
        wohnort: "Zürich",
        beruf: "Koch"
    },

    {
        id: 6,
        name: "Mia Mutard",
        alter: "51 Jahre alt.",
        wohnort: "Baden",
        beruf: "Pflegefachfrau"
    },

    {
        id: 7,
        name: "Mark Weis",
        alter: "40 Jahre alt",
        wohnort: "Spreitenbach",
        beruf: "Augenarzt"
    },

    {
        id: 7,
        name: "Benjamin Blocher",
        alter: "22 Jahre alt.",
        wohnort: "Würenlos",
        beruf: "Arzt"
    }
  ]
  };
  